/**
 * @fileoverview Este archivo contiene las funciones javascript utilizadas en el
 * formulario de CAIE
 *
 * El sistema de documentacion de los ficheros JS es <a href='http://code.google.com/p/jsdoc-toolkit'>jsdoc-toolkit</a>
 * @author Gustavo Lacoste gustavo@lacosox.org
 * @version 0.1
 */
var SuperControlador = function() {
    var parsearData=function(){};
}
/**
 * Recibe un Objeto JSON y lo vuelca sobre el DOM actual.
 * @function
 **/
SuperControlador.prototype.parsearData= function(obj){
  //$('form').loadJSON(obj);
  
} //END FormIngresoEncuestado.prototype.inicializar